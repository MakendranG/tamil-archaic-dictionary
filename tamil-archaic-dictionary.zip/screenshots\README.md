# Screenshots Folder

This folder should contain screenshots of your application for documentation and blog post.

## Required Screenshots

### 1. main-interface.png
- Full page view of the application
- Search box and example buttons visible
- Clean, professional appearance
- Recommended size: 1920x1080 or 1280x720

### 2. tamil-keyboard.png
- Virtual Tamil keyboard open and visible
- All character sections (vowels, consonants, combinations) shown
- Keyboard controls visible
- Recommended size: 1920x1080 or 1280x720

### 3. search-results.png
- Example search performed (e.g., "அடியும்")
- Tamil meaning displayed
- English meaning displayed
- Examples section visible
- Etymology section visible
- Recommended size: 1920x1080 or 1280x720

### 4. kiro-in-action.png (for blog post)
- Screenshot of Kiro IDE interface
- Shows code generation or assistance
- Chat conversation visible
- Recommended size: 1920x1080 or 1280x720

## Optional Screenshots

### 5. mobile-view.png
- Application on mobile device
- Responsive design demonstration
- Recommended size: 375x812 (iPhone) or 360x640 (Android)

### 6. online-search.png
- Loading state or online search result
- Source badge visible
- Recommended size: 1920x1080 or 1280x720

### 7. no-results.png
- Error state when word not found
- User-friendly error message
- Recommended size: 1920x1080 or 1280x720

## How to Take Screenshots

### Windows
- **Full Screen**: Press `Win + PrtScn` (saves to Pictures/Screenshots)
- **Snipping Tool**: Press `Win + Shift + S` (select area)
- **Browser DevTools**: F12 → Device Toolbar (for mobile view)

### Mac
- **Full Screen**: Press `Cmd + Shift + 3`
- **Selected Area**: Press `Cmd + Shift + 4`
- **Browser DevTools**: Cmd + Option + I → Device Toolbar

### Linux
- **Full Screen**: Press `PrtScn`
- **Selected Area**: Press `Shift + PrtScn`
- **Screenshot Tool**: Use GNOME Screenshot or similar

## Screenshot Tips

1. **Clean Browser**: Close unnecessary tabs and bookmarks bar
2. **Full Screen**: Use F11 for distraction-free screenshots
3. **Good Lighting**: Ensure text is readable
4. **Consistent Size**: Keep all screenshots at similar resolution
5. **Crop Properly**: Remove unnecessary whitespace
6. **Compress**: Use tools like TinyPNG to reduce file size
7. **Format**: PNG for UI screenshots, JPG for photos

## Image Optimization

Before uploading to GitHub or blog:

```bash
# Using ImageMagick (if installed)
convert main-interface.png -resize 1280x720 -quality 85 main-interface-optimized.png

# Or use online tools:
# - TinyPNG: https://tinypng.com
# - Squoosh: https://squoosh.app
# - Compressor.io: https://compressor.io
```

## Adding Screenshots to README

Update the main README.md with:

```markdown
## 🎨 Screenshots

### Main Interface
![Main Interface](screenshots/main-interface.png)

### Tamil Keyboard
![Tamil Keyboard](screenshots/tamil-keyboard.png)

### Search Results
![Search Results](screenshots/search-results.png)
```

## Adding Screenshots to Blog Post

Upload to AWS Builder Center and use:

```markdown
![Main Interface](https://your-image-url.com/main-interface.png)
*Caption: Clean and intuitive main interface*
```

---

**Note**: This folder is currently empty. Add your screenshots here before submitting!
