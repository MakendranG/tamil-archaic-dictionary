# 📚 Tamil Archaic Word Dictionary

> A single-purpose web application that solves the problem of understanding complex Tamil literary and archaic words by providing simple modern Tamil meanings and English equivalents.

[![Live Demo](https://img.shields.io/badge/demo-live-success)](https://your-demo-link.com)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## 🎯 Problem Statement

Tamil literature is rich with archaic and formal words that are difficult for modern readers to understand. Students, researchers, and Tamil language enthusiasts often struggle to find simple, accessible meanings for these classical terms. Existing dictionaries are either too complex, not digitized, or lack modern Tamil explanations.

## ✨ Solution

A clean, intuitive web application that:
- Provides instant translations of archaic Tamil words to modern Tamil and English
- Includes a virtual Tamil keyboard for easy input
- Searches online databases when words aren't found locally
- Shows usage examples and etymology for better understanding
- Works on all devices with a responsive design

## 🚀 Features

### 1. **Virtual Tamil Keyboard**
- Full Tamil character support (vowels, consonants, combinations)
- No need for Tamil keyboard installation
- Works on any device or operating system

### 2. **Dual Dictionary System**
- **Local Dictionary**: 30+ pre-loaded archaic words for instant results
- **Online Search**: Automatic fallback to Wiktionary and translation APIs

### 3. **Comprehensive Word Information**
- Word type classification (verb, noun, participle, etc.)
- Simple modern Tamil meaning
- English translation
- Usage examples with context
- Etymology and word history

### 4. **User-Friendly Interface**
- Clean, modern design with gradient backgrounds
- Quick example buttons for testing
- Mobile-responsive layout
- Smooth animations and transitions

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **APIs**: 
  - Wiktionary REST API
  - MyMemory Translation API
- **Design**: Responsive CSS Grid & Flexbox
- **No Dependencies**: Pure vanilla implementation

## 📦 Installation & Setup

### Local Development

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/tamil-archaic-dictionary.git
cd tamil-archaic-dictionary
```

2. **Open in browser**
```bash
# Simply open index.html in your browser
# Or use a local server:
python -m http.server 8000
# Then visit: http://localhost:8000
```

### Deployment Options

#### Option 1: GitHub Pages
1. Go to repository Settings → Pages
2. Select main branch as source
3. Your site will be live at: `https://yourusername.github.io/tamil-archaic-dictionary`

#### Option 2: Netlify
1. Connect your GitHub repository to Netlify
2. Deploy with default settings
3. Site goes live automatically

#### Option 3: AWS S3 Static Hosting
1. Create an S3 bucket
2. Enable static website hosting
3. Upload all files
4. Set bucket policy for public access

## 📖 Usage Guide

### Basic Search
1. Type or use the virtual keyboard to enter a Tamil word
2. Click "தேடு" (Search) or press Enter
3. View the meaning, examples, and etymology

### Virtual Keyboard
1. Click the keyboard icon (⌨️) to open
2. Click Tamil characters to insert them
3. Use Backspace, Clear, or Space controls
4. Close when done

### Online Search
- Toggle "Search online if not found locally" to enable/disable
- When enabled, searches external APIs automatically
- Shows source badge indicating where the result came from

## 🎨 Screenshots

### Main Interface
![Main Interface](screenshots/main-interface.png)

### Tamil Keyboard
![Tamil Keyboard](screenshots/tamil-keyboard.png)

### Search Results
![Search Results](screenshots/search-results.png)

## 🤖 Built with Kiro AI

This project was developed with significant assistance from Kiro AI, which accelerated development by:

- **Rapid Prototyping**: Generated initial HTML/CSS/JS structure in minutes
- **Feature Implementation**: Added Tamil keyboard and API integration quickly
- **Code Quality**: Ensured clean, maintainable code with proper structure
- **Problem Solving**: Helped debug API integration and responsive design issues
- **Documentation**: Assisted in creating comprehensive README and blog post

### Development Timeline
- **Initial Setup**: 10 minutes (with Kiro)
- **Tamil Keyboard**: 15 minutes (with Kiro)
- **API Integration**: 20 minutes (with Kiro)
- **Total Development Time**: ~1 hour (would have taken 6-8 hours manually)

## 📝 Dictionary Coverage

### Current Local Dictionary (30+ words)
- Verbs: அடியும், கண்டீர், செய்யும், வருக, படிக்கும், பேசும், etc.
- Participles: கொண்டு, செய்து, வந்து, போய்
- Common words: உண்டு, இல்லை, நினைவு

### Online Coverage
- Thousands of additional words via Wiktionary
- Translation support for modern Tamil words

## 🔮 Future Enhancements

- [ ] Voice input for Tamil words
- [ ] Save favorite words
- [ ] Word of the day feature
- [ ] Expand local dictionary to 500+ words
- [ ] Add pronunciation guide
- [ ] Tamil-to-Tamil dictionary mode
- [ ] Export word lists
- [ ] Dark mode theme

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. **Add More Words**: Expand the dictionary in `script.js`
2. **Improve UI/UX**: Enhance the design and user experience
3. **Add Features**: Implement items from the future enhancements list
4. **Fix Bugs**: Report and fix any issues you find

### How to Contribute
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)
- LinkedIn: [Your LinkedIn](https://linkedin.com/in/yourprofile)
- Email: your.email@example.com

## 🙏 Acknowledgments

- **AI for Bharat Program**: For the opportunity and challenge
- **Kiro AI**: For accelerating development and providing intelligent assistance
- **Tamil Language Community**: For preserving and promoting Tamil literature
- **Open Source APIs**: Wiktionary and MyMemory for their free services

## 📊 Project Stats

- **Lines of Code**: ~800
- **Development Time**: 1 hour with Kiro AI
- **Dictionary Size**: 30+ words (local) + unlimited (online)
- **Supported Devices**: All (responsive design)
- **API Calls**: Free tier (no limits for personal use)

---

**Built with ❤️ for Tamil language enthusiasts**

**Part of AI for Bharat - Week 1: Micro-Tools Challenge**
