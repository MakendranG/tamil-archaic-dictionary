# Screenshot Guide for Blog Post

## 📸 Required Screenshots for AI for Bharat Submission

### Screenshot 1: Main Interface ⭐ REQUIRED

**What to capture:**
- Full browser window showing the application
- Search input box clearly visible
- Example buttons (அடியும், கண்டீர், etc.) shown
- Clean, professional appearance
- No browser tabs or bookmarks visible (use F11 for fullscreen)

**How to take:**
1. Open `index.html` in browser
2. Press F11 for fullscreen mode
3. Make sure page is fully loaded
4. Press `Win + Shift + S` (Windows) or `Cmd + Shift + 4` (Mac)
5. Select the entire browser window
6. Save as: `screenshots/main-interface.png`

**Checklist:**
- [ ] Full page visible
- [ ] Search box in focus
- [ ] Example buttons shown
- [ ] No browser UI visible
- [ ] High resolution (1920x1080 or 1280x720)

---

### Screenshot 2: Tamil Keyboard ⭐ REQUIRED

**What to capture:**
- Virtual Tamil keyboard open and visible
- All three sections visible:
  - உயிர் எழுத்துக்கள் (Vowels)
  - மெய் எழுத்துக்கள் (Consonants)
  - உயிர்மெய் எழுத்துக்கள் (Combinations)
- Keyboard controls (Backspace, Clear, Space) visible

**How to take:**
1. Open application
2. Click the keyboard icon (⌨️)
3. Wait for keyboard to fully expand
4. Scroll if needed to show all sections
5. Take screenshot
6. Save as: `screenshots/tamil-keyboard.png`

**Checklist:**
- [ ] Keyboard fully visible
- [ ] All character sections shown
- [ ] Controls visible at bottom
- [ ] Clear and readable
- [ ] High resolution

---

### Screenshot 3: Search Results ⭐ REQUIRED

**What to capture:**
- A word searched (e.g., "அடியும்")
- Tamil meaning displayed
- English meaning displayed
- Examples section visible
- Etymology section visible
- Source badge (if online search)

**How to take:**
1. Type or click example word "அடியும்"
2. Click "தேடு" (Search)
3. Wait for results to display
4. Scroll to show all sections
5. Take screenshot
6. Save as: `screenshots/search-results.png`

**Checklist:**
- [ ] Word clearly shown at top
- [ ] Word type badge visible
- [ ] Tamil meaning visible
- [ ] English meaning visible
- [ ] Examples section shown
- [ ] Etymology section shown
- [ ] Clean layout

---

### Screenshot 4: Kiro in Action ⭐ REQUIRED FOR BLOG

**What to capture:**
- Kiro IDE interface
- Your chat with Kiro showing assistance
- Code generation or suggestions visible
- File explorer showing project files

**How to take:**
1. Open Kiro IDE
2. Show a conversation where Kiro helped you
3. Make sure code is visible
4. Take screenshot
5. Save as: `screenshots/kiro-in-action.png`

**Example conversations to capture:**
- Initial project setup request
- Tamil keyboard implementation
- API integration help
- Bug fixing assistance

**Checklist:**
- [ ] Kiro chat visible
- [ ] Your request shown
- [ ] Kiro's response shown
- [ ] Code visible (if applicable)
- [ ] Professional appearance

---

### Screenshot 5: Mobile View (Optional but Recommended)

**What to capture:**
- Application on mobile device or mobile view
- Responsive design working correctly
- Keyboard on mobile (if possible)

**How to take:**
1. Open browser DevTools (F12)
2. Click device toolbar icon (or Ctrl+Shift+M)
3. Select iPhone or Android device
4. Take screenshot
5. Save as: `screenshots/mobile-view.png`

**Checklist:**
- [ ] Mobile layout visible
- [ ] All elements fit screen
- [ ] Readable text
- [ ] Functional design

---

### Screenshot 6: Online Search Result (Optional)

**What to capture:**
- Loading spinner (if you can catch it)
- Result from online API
- Source badge showing "Wiktionary" or "Translation API"

**How to take:**
1. Search for a word NOT in local dictionary
2. Enable online search
3. Capture the result with source badge
4. Save as: `screenshots/online-search.png`

**Checklist:**
- [ ] Source badge visible
- [ ] Online result shown
- [ ] Different from local results

---

## 🎨 Screenshot Best Practices

### Before Taking Screenshots

1. **Clean Browser**
   - Close unnecessary tabs
   - Hide bookmarks bar (Ctrl+Shift+B)
   - Use fullscreen mode (F11)
   - Clear browser console

2. **Optimize Display**
   - Set zoom to 100% (Ctrl+0)
   - Use good screen resolution
   - Ensure good contrast
   - Check text readability

3. **Test Everything**
   - Verify all features work
   - Check Tamil characters display
   - Test on different browsers
   - Ensure no errors in console

### Taking Screenshots

**Windows:**
```
Win + Shift + S  → Select area
Win + PrtScn     → Full screen (saves to Pictures/Screenshots)
Alt + PrtScn     → Active window only
```

**Mac:**
```
Cmd + Shift + 3  → Full screen
Cmd + Shift + 4  → Select area
Cmd + Shift + 4 + Space → Window capture
```

**Linux:**
```
PrtScn           → Full screen
Shift + PrtScn   → Select area
Alt + PrtScn     → Active window
```

### After Taking Screenshots

1. **Review Quality**
   - Check resolution
   - Verify text is readable
   - Ensure no sensitive info visible
   - Confirm colors look good

2. **Edit if Needed**
   - Crop unnecessary parts
   - Add arrows or highlights (optional)
   - Blur sensitive information
   - Resize if too large

3. **Optimize File Size**
   - Use PNG for UI screenshots
   - Compress with TinyPNG or similar
   - Keep under 1MB per image
   - Maintain quality

---

## 🖼️ Screenshot Specifications

### Recommended Sizes

| Screenshot | Recommended Size | Max Size |
|-----------|------------------|----------|
| Main Interface | 1920x1080 | 2MB |
| Tamil Keyboard | 1920x1080 | 2MB |
| Search Results | 1920x1080 | 2MB |
| Kiro in Action | 1920x1080 | 2MB |
| Mobile View | 375x812 | 1MB |

### File Format
- **Format**: PNG (for UI) or JPG (for photos)
- **Color**: RGB
- **Compression**: Medium to High
- **Naming**: Lowercase with hyphens (e.g., `main-interface.png`)

---

## 📝 Adding Screenshots to Documents

### In README.md

```markdown
## 🎨 Screenshots

### Main Interface
![Main Interface](screenshots/main-interface.png)
*Clean and intuitive interface for searching Tamil words*

### Tamil Keyboard
![Tamil Keyboard](screenshots/tamil-keyboard.png)
*Virtual keyboard with all Tamil characters*

### Search Results
![Search Results](screenshots/search-results.png)
*Comprehensive word information with examples*
```

### In Blog Post (AWS Builder Center)

1. Upload images to AWS Builder Center
2. Get image URLs
3. Use in markdown:

```markdown
![Main Interface](https://your-image-url.com/main-interface.png)
*Caption: The main interface provides a clean search experience*
```

---

## 🎬 Alternative: Screen Recording

Instead of screenshots, you can create a short video:

### Tools
- **Windows**: Xbox Game Bar (Win + G)
- **Mac**: QuickTime Player (Cmd + Shift + 5)
- **Cross-platform**: OBS Studio (free)

### What to Record (30-60 seconds)
1. Open application
2. Click keyboard icon
3. Type a Tamil word using keyboard
4. Click search
5. Show results
6. Scroll through examples

### Video Specs
- **Length**: 30-60 seconds
- **Format**: MP4
- **Resolution**: 1280x720 or 1920x1080
- **Size**: Under 50MB
- **Upload**: YouTube or Vimeo, then embed link

---

## ✅ Screenshot Checklist

Before submitting, verify:

- [ ] All 4 required screenshots taken
- [ ] Screenshots are high quality
- [ ] Text is readable
- [ ] No sensitive information visible
- [ ] Files saved in `screenshots/` folder
- [ ] Files named correctly
- [ ] File sizes are reasonable (< 2MB each)
- [ ] Screenshots added to README.md
- [ ] Screenshots uploaded for blog post

---

## 🎯 Quick Screenshot Workflow

**Total Time: 10 minutes**

1. **Prepare** (2 min)
   - Open application in browser
   - Press F11 for fullscreen
   - Test all features

2. **Capture** (5 min)
   - Main interface → Save
   - Open keyboard → Save
   - Search word → Save
   - Open Kiro IDE → Save

3. **Review** (2 min)
   - Check all images
   - Verify quality
   - Rename if needed

4. **Optimize** (1 min)
   - Compress if needed
   - Move to screenshots folder

---

## 💡 Pro Tips

1. **Use Consistent Browser**: Take all screenshots in same browser
2. **Same Zoom Level**: Keep 100% zoom for consistency
3. **Good Lighting**: If taking photos of screen, ensure good lighting
4. **Multiple Takes**: Take 2-3 shots of each, pick the best
5. **Annotate Later**: You can add arrows/highlights in image editor
6. **Test Display**: View screenshots on different devices
7. **Backup**: Keep original high-res versions

---

## 🆘 Troubleshooting

### Issue: Tamil Characters Show as Boxes

**Solution:**
- This is normal on some systems
- They will display correctly in browsers
- Take screenshot in Chrome or Firefox
- Verify on different device

### Issue: Screenshot Too Large

**Solution:**
```bash
# Use online tools:
# - TinyPNG: https://tinypng.com
# - Squoosh: https://squoosh.app

# Or command line (if ImageMagick installed):
convert input.png -resize 1280x720 -quality 85 output.png
```

### Issue: Blurry Screenshots

**Solution:**
- Increase screen resolution
- Use 100% zoom in browser
- Take screenshot in native resolution
- Don't upscale small images

### Issue: Can't Capture Keyboard

**Solution:**
- Click keyboard icon
- Wait for animation to complete
- Use Snipping Tool (Win + Shift + S)
- Select area manually

---

## 📚 Resources

- **Image Compression**: https://tinypng.com
- **Image Editing**: https://www.photopea.com (free Photoshop alternative)
- **Screen Recording**: https://obsproject.com
- **Screenshot Tools**: https://www.screenpresso.com

---

## 🎉 Ready to Capture!

Follow this guide and you'll have professional screenshots for your submission in just 10 minutes.

**Remember:**
- Quality over quantity
- Clear and readable
- Professional appearance
- Show key features

**Good luck! 📸**
