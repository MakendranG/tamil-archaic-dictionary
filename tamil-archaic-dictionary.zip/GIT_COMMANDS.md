# Git Commands for Submission

## 🚀 Quick Copy-Paste Commands

### Step 1: Initialize Git Repository

```bash
# Navigate to your project folder
cd tamil-archaic-dictionary

# Initialize git
git init

# Check status
git status
```

### Step 2: Add All Files

```bash
# Add all files to staging
git add .

# Verify what will be committed
git status

# Check if .kiro is included (IMPORTANT!)
git ls-files | grep .kiro
```

### Step 3: First Commit

```bash
# Create initial commit
git commit -m "Initial commit - Tamil Archaic Word Dictionary for AI for Bharat Week 1"

# Verify commit
git log --oneline
```

### Step 4: Connect to GitHub

```bash
# Replace YOUR_USERNAME with your GitHub username
git remote add origin https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git

# Verify remote
git remote -v

# Rename branch to main (if needed)
git branch -M main
```

### Step 5: Push to GitHub

```bash
# Push to GitHub
git push -u origin main

# If you get an error about authentication, use:
# git push -u origin main --force
```

---

## 🔍 Verification Commands

### Check if .kiro Directory is Tracked

```bash
# List all tracked files containing .kiro
git ls-files | grep .kiro

# If nothing shows, .kiro is NOT tracked!
# Fix it with:
git add -f .kiro/
git commit -m "Add .kiro directory"
git push
```

### Check Repository Status

```bash
# See what's tracked
git status

# See commit history
git log --oneline

# See all tracked files
git ls-files
```

### Check Remote Connection

```bash
# View remote URL
git remote -v

# Should show:
# origin  https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git (fetch)
# origin  https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git (push)
```

---

## 🛠️ Common Issues & Fixes

### Issue 1: .kiro Directory Not Tracked

**Problem**: .kiro folder is not showing in GitHub

**Solution**:
```bash
# Check if .kiro is in .gitignore
cat .gitignore | grep .kiro

# If it shows ".kiro/", edit .gitignore and remove that line
# Then force add:
git add -f .kiro/
git commit -m "Add .kiro directory for AI for Bharat submission"
git push
```

### Issue 2: Authentication Failed

**Problem**: Git push asks for password but doesn't work

**Solution Option 1 - Use Personal Access Token**:
```bash
# 1. Go to GitHub → Settings → Developer settings → Personal access tokens
# 2. Generate new token (classic)
# 3. Select "repo" scope
# 4. Copy the token
# 5. Use token as password when pushing

git push -u origin main
# Username: YOUR_USERNAME
# Password: [paste your token]
```

**Solution Option 2 - Use GitHub CLI**:
```bash
# Install GitHub CLI: https://cli.github.com/
# Then authenticate:
gh auth login

# Follow prompts, then push:
git push -u origin main
```

**Solution Option 3 - Use SSH**:
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Add to SSH agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# Copy public key
cat ~/.ssh/id_ed25519.pub

# Add to GitHub: Settings → SSH and GPG keys → New SSH key
# Then change remote URL:
git remote set-url origin git@github.com:YOUR_USERNAME/tamil-archaic-dictionary.git

# Push
git push -u origin main
```

### Issue 3: Repository Already Exists

**Problem**: "remote origin already exists"

**Solution**:
```bash
# Remove existing remote
git remote remove origin

# Add correct remote
git remote add origin https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git

# Push
git push -u origin main
```

### Issue 4: Divergent Branches

**Problem**: "Updates were rejected because the tip of your current branch is behind"

**Solution**:
```bash
# Pull first (if you initialized with README on GitHub)
git pull origin main --allow-unrelated-histories

# Then push
git push -u origin main

# OR force push (only if you're sure)
git push -u origin main --force
```

### Issue 5: Large Files

**Problem**: "file is too large" error

**Solution**:
```bash
# Check file sizes
find . -type f -size +50M

# If you have large files, add to .gitignore
echo "large-file.zip" >> .gitignore

# Remove from git cache
git rm --cached large-file.zip

# Commit and push
git commit -m "Remove large files"
git push
```

---

## 📝 Making Changes After Initial Push

### Update Files

```bash
# Make your changes to files
# Then:

# See what changed
git status

# Add changed files
git add .

# Commit with message
git commit -m "Update: description of changes"

# Push to GitHub
git push
```

### Add New Files

```bash
# Create new file
# Then:

# Add to git
git add new-file.txt

# Commit
git commit -m "Add new file"

# Push
git push
```

### Delete Files

```bash
# Delete file
git rm file-to-delete.txt

# Commit
git commit -m "Remove unnecessary file"

# Push
git push
```

---

## 🌿 Branch Management (Optional)

### Create Feature Branch

```bash
# Create and switch to new branch
git checkout -b feature/new-feature

# Make changes, then:
git add .
git commit -m "Add new feature"

# Push branch
git push -u origin feature/new-feature

# Switch back to main
git checkout main

# Merge feature
git merge feature/new-feature

# Push main
git push
```

---

## 🔄 Syncing with GitHub

### Pull Latest Changes

```bash
# Get latest from GitHub
git pull origin main
```

### Check for Updates

```bash
# Fetch without merging
git fetch origin

# See differences
git diff main origin/main
```

---

## 📊 Useful Git Commands

### View History

```bash
# See commit history
git log

# See compact history
git log --oneline

# See last 5 commits
git log -5

# See changes in each commit
git log -p
```

### View Changes

```bash
# See unstaged changes
git diff

# See staged changes
git diff --staged

# See changes in specific file
git diff filename.txt
```

### Undo Changes

```bash
# Undo changes in working directory
git checkout -- filename.txt

# Unstage file
git reset HEAD filename.txt

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo last commit (discard changes)
git reset --hard HEAD~1
```

---

## 🎯 Complete Workflow Example

```bash
# 1. Initialize
cd tamil-archaic-dictionary
git init

# 2. Add files
git add .

# 3. Verify .kiro is included
git ls-files | grep .kiro

# 4. Commit
git commit -m "Initial commit - Tamil Archaic Word Dictionary"

# 5. Connect to GitHub
git remote add origin https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git

# 6. Push
git branch -M main
git push -u origin main

# 7. Verify on GitHub
# Visit: https://github.com/YOUR_USERNAME/tamil-archaic-dictionary

# 8. Enable GitHub Pages
# Settings → Pages → Source: main branch → Save

# 9. Wait 2-3 minutes, then visit:
# https://YOUR_USERNAME.github.io/tamil-archaic-dictionary
```

---

## ✅ Pre-Submission Checklist

Run these commands to verify everything:

```bash
# 1. Check git status
git status
# Should show: "nothing to commit, working tree clean"

# 2. Check .kiro is tracked
git ls-files | grep .kiro
# Should show .kiro files

# 3. Check remote
git remote -v
# Should show your GitHub URL

# 4. Check last commit
git log -1
# Should show your commit message

# 5. Verify on GitHub
# Visit your repository URL and check:
# - All files are there
# - .kiro directory is visible
# - README displays correctly
```

---

## 🆘 Emergency Commands

### Start Over (Nuclear Option)

```bash
# WARNING: This deletes everything!
# Only use if you want to completely start over

# Remove git
rm -rf .git

# Re-initialize
git init
git add .
git commit -m "Fresh start"
git remote add origin YOUR_REPO_URL
git push -u origin main --force
```

### Fix Corrupted Repository

```bash
# If git is acting weird
git fsck

# Garbage collection
git gc

# Prune old data
git prune
```

---

## 📚 Git Resources

- **Git Documentation**: https://git-scm.com/doc
- **GitHub Guides**: https://guides.github.com/
- **Git Cheat Sheet**: https://education.github.com/git-cheat-sheet-education.pdf
- **Interactive Tutorial**: https://learngitbranching.js.org/

---

## 💡 Pro Tips

1. **Commit Often**: Small, frequent commits are better than large ones
2. **Write Good Messages**: Describe what and why, not how
3. **Check Before Push**: Always run `git status` before pushing
4. **Use .gitignore**: Don't commit unnecessary files
5. **Backup Important**: Keep local backups before force operations

---

## 🎉 You're Ready!

With these commands, you can:
- ✅ Initialize your repository
- ✅ Push to GitHub
- ✅ Verify .kiro is included
- ✅ Fix common issues
- ✅ Make updates

**Next Steps:**
1. Run the commands above
2. Verify on GitHub
3. Enable GitHub Pages
4. Take screenshots
5. Write blog post
6. Submit to dashboard

**Good luck with your submission! 🚀**
