// Expanded Tamil Archaic Word Dictionary Database
const dictionary = {
    'அடியும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'அடிப்பது, தாக்குவது',
        englishMeaning: 'To hit, to strike, to beat',
        examples: ['அவன் பந்தை அடியும் - He will hit the ball', 'காற்று மரத்தை அடியும் - The wind strikes the tree'],
        etymology: 'பழந்தமிழில் "அடி" என்ற வேர்ச்சொல்லிலிருந்து வந்தது. "அடி" + "உம்" (எதிர்கால இடைநிலை)'
    },
    'கண்டீர்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'பார்த்தீர்கள், நீங்கள் பார்த்தீர்கள்',
        englishMeaning: 'You saw, you have seen (respectful plural)',
        examples: ['நீங்கள் அதை கண்டீர் - You saw it', 'இந்த அழகை கண்டீர் - You have seen this beauty'],
        etymology: '"காண்" (to see) வினையின் இறந்தகால வடிவம். மரியாதைக்குரிய பன்மை வடிவம்.'
    },
    'செய்யும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'செய்வது, செய்யப்படும்',
        englishMeaning: 'Will do, will make, does',
        examples: ['அவன் வேலை செய்யும் - He will do the work', 'இயற்கை அதிசயங்களை செய்யும் - Nature does wonders'],
        etymology: '"செய்" வினையின் எதிர்கால வடிவம். "செய்" + "உம்" (எதிர்கால இடைநிலை)'
    },
    'வருக': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'வா, வாருங்கள் (கட்டளை)',
        englishMeaning: 'Come (imperative form)',
        examples: ['இங்கே வருக - Come here', 'என்னுடன் வருக - Come with me'],
        etymology: '"வா" வினையின் கட்டளை வடிவம். மரியாதைக்குரிய வடிவம்.'
    },
    'அறிவீர்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'தெரியும், அறிவீர்கள்',
        englishMeaning: 'You know (respectful)',
        examples: ['நீங்கள் இதை அறிவீர் - You know this', 'உண்மையை அறிவீர் - You know the truth'],
        etymology: '"அறி" (to know) வினையின் நிகழ்கால மரியாதை வடிவம்'
    },
    'செய்தீர்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'செய்தீர்கள், நீங்கள் செய்தீர்கள்',
        englishMeaning: 'You did, you have done (respectful)',
        examples: ['நீங்கள் நன்றாக செய்தீர் - You did well', 'இந்த வேலையை செய்தீர் - You have done this work'],
        etymology: '"செய்" வினையின் இறந்தகால மரியாதை வடிவம்'
    },
    'கூறும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'சொல்லும், கூறுவது',
        englishMeaning: 'Will say, tells, speaks',
        examples: ['அவன் உண்மையை கூறும் - He will tell the truth', 'புத்தகம் கதையை கூறும் - The book tells the story'],
        etymology: '"கூறு" வினையின் எதிர்கால வடிவம்'
    },
    'உண்டு': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'இருக்கிறது, உள்ளது',
        englishMeaning: 'Exists, is there, is present',
        examples: ['வீட்டில் உணவு உண்டு - There is food at home', 'நம்பிக்கை உண்டு - There is hope'],
        etymology: 'பழந்தமிழில் இருப்பைக் குறிக்கும் சொல்'
    },
    'இல்லை': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'இல்லை, கிடையாது',
        englishMeaning: 'Is not, does not exist, no',
        examples: ['அங்கே யாரும் இல்லை - There is no one there', 'பணம் இல்லை - There is no money'],
        etymology: 'இல்லாமையைக் குறிக்கும் எதிர்மறை வினைச்சொல்'
    },
    'கொண்டு': {
        type: 'வினையெச்சம் (Verbal Participle)',
        tamilMeaning: 'எடுத்து, வைத்து',
        englishMeaning: 'Taking, having taken, with',
        examples: ['புத்தகத்தை கொண்டு வா - Bring the book (taking it)', 'அன்பு கொண்டு செய் - Do it with love'],
        etymology: '"கொள்" வினையின் வினையெச்ச வடிவம்'
    },
    'செய்து': {
        type: 'வினையெச்சம் (Verbal Participle)',
        tamilMeaning: 'செய்து, செய்த பின்',
        englishMeaning: 'Having done, after doing',
        examples: ['வேலை செய்து வா - Come after doing work', 'சமைத்து செய்து பரிமாறு - Cook and serve'],
        etymology: '"செய்" வினையின் வினையெச்ச வடிவம்'
    },
    'வந்து': {
        type: 'வினையெச்சம் (Verbal Participle)',
        tamilMeaning: 'வந்த பின், வந்து',
        englishMeaning: 'Having come, after coming',
        examples: ['வீட்டுக்கு வந்து சாப்பிடு - Come home and eat', 'அவன் வந்து சொன்னான் - He came and told'],
        etymology: '"வா" வினையின் வினையெச்ச வடிவம்'
    },
    'போய்': {
        type: 'வினையெச்சம் (Verbal Participle)',
        tamilMeaning: 'சென்று, போன பின்',
        englishMeaning: 'Having gone, after going',
        examples: ['கடைக்கு போய் வா - Go to the shop and come', 'அவன் போய் விட்டான் - He has gone'],
        etymology: '"போ" வினையின் வினையெச்ச வடிவம்'
    },
    'ஆகும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'ஆகிவிடும், மாறும்',
        englishMeaning: 'Will become, will be',
        examples: ['அவன் மருத்துவர் ஆகும் - He will become a doctor', 'இது சாத்தியம் ஆகும் - This will be possible'],
        etymology: '"ஆகு" வினையின் எதிர்கால வடிவம்'
    },
    'கூடும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'முடியும், சாத்தியம்',
        englishMeaning: 'Can, is possible, may',
        examples: ['இது நடக்க கூடும் - This may happen', 'அவனால் செய்ய கூடும் - He can do it'],
        etymology: 'சாத்தியத்தைக் குறிக்கும் துணை வினைச்சொல்'
    },
    'நினைவு': {
        type: 'பெயர்ச்சொல் (Noun)',
        tamilMeaning: 'ஞாபகம், நினைப்பு',
        englishMeaning: 'Memory, remembrance, thought',
        examples: ['அவன் என் நினைவில் இருக்கிறான் - He is in my memory', 'நல்ல நினைவுகள் - Good memories'],
        etymology: '"நினை" வினையிலிருந்து வந்த பெயர்ச்சொல்'
    },
    'எழுதும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'எழுதுவது, எழுதப்படும்',
        englishMeaning: 'Will write, writes',
        examples: ['அவன் கடிதம் எழுதும் - He will write a letter'],
        etymology: '"எழுது" வினையின் எதிர்கால வடிவம்'
    },
    'படிக்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'படிப்பது, படிக்கப்படும்',
        englishMeaning: 'Will read, reads, will study',
        examples: ['அவள் புத்தகம் படிக்கும் - She will read the book'],
        etymology: '"படி" வினையின் எதிர்கால வடிவம்'
    },
    'பேசும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'பேசுவது, பேசப்படும்',
        englishMeaning: 'Will speak, speaks, will talk',
        examples: ['அவன் தமிழில் பேசும் - He will speak in Tamil'],
        etymology: '"பேசு" வினையின் எதிர்கால வடிவம்'
    },
    'கேட்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'கேட்பது, கேட்கப்படும்',
        englishMeaning: 'Will hear, will listen, will ask',
        examples: ['அவன் பாடலை கேட்கும் - He will listen to the song'],
        etymology: '"கேள்" வினையின் எதிர்கால வடிவம்'
    },
    'நடக்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'நடப்பது, நடைபெறும்',
        englishMeaning: 'Will walk, will happen, will occur',
        examples: ['திருவிழா நடக்கும் - The festival will happen'],
        etymology: '"நட" வினையின் எதிர்கால வடிவம்'
    },
    'ஓடும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'ஓடுவது, ஓடப்படும்',
        englishMeaning: 'Will run, runs',
        examples: ['குதிரை வேகமாக ஓடும் - The horse will run fast'],
        etymology: '"ஓடு" வினையின் எதிர்கால வடிவம்'
    },
    'தூங்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'தூங்குவது, உறங்குவது',
        englishMeaning: 'Will sleep, sleeps',
        examples: ['குழந்தை இரவில் தூங்கும் - The child will sleep at night'],
        etymology: '"தூங்கு" வினையின் எதிர்கால வடிவம்'
    },
    'சாப்பிடும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'சாப்பிடுவது, உண்ணும்',
        englishMeaning: 'Will eat, eats',
        examples: ['அவன் உணவை சாப்பிடும் - He will eat the food'],
        etymology: '"சாப்பிடு" வினையின் எதிர்கால வடிவம்'
    },
    'குடிக்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'குடிப்பது, அருந்தும்',
        englishMeaning: 'Will drink, drinks',
        examples: ['அவள் தண்ணீர் குடிக்கும் - She will drink water'],
        etymology: '"குடி" வினையின் எதிர்கால வடிவம்'
    },
    'விளையாடும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'விளையாடுவது, விளையாட்டு',
        englishMeaning: 'Will play, plays',
        examples: ['குழந்தைகள் விளையாடும் - Children will play'],
        etymology: '"விளையாடு" வினையின் எதிர்கால வடிவம்'
    },
    'பார்க்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'பார்ப்பது, காணும்',
        englishMeaning: 'Will see, will look, will watch',
        examples: ['அவன் திரைப்படம் பார்க்கும் - He will watch the movie'],
        etymology: '"பார்" வினையின் எதிர்கால வடிவம்'
    },
    'கற்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'கற்பது, படிப்பது',
        englishMeaning: 'Will learn, learns',
        examples: ['மாணவன் தமிழ் கற்கும் - The student will learn Tamil'],
        etymology: '"கல்" வினையின் எதிர்கால வடிவம்'
    },
    'சிரிக்கும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'சிரிப்பது, நகைப்பது',
        englishMeaning: 'Will laugh, laughs, will smile',
        examples: ['அவள் நகைச்சுவையைக் கேட்டு சிரிக்கும் - She will laugh hearing the joke'],
        etymology: '"சிரி" வினையின் எதிர்கால வடிவம்'
    },
    'அழும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'அழுவது, கண்ணீர் விடுவது',
        englishMeaning: 'Will cry, cries, will weep',
        examples: ['குழந்தை அழும் - The baby will cry'],
        etymology: '"அழு" வினையின் எதிர்கால வடிவம்'
    },
    'பாடும்': {
        type: 'வினைச்சொல் (Verb)',
        tamilMeaning: 'பாடுவது, பாட்டு பாடுவது',
        englishMeaning: 'Will sing, sings',
        examples: ['பறவை பாடும் - The bird will sing'],
        etymology: '"பாடு" வினையின் எதிர்கால வடிவம்'
    }
};

// Tamil Keyboard Characters
const tamilChars = {
    vowels: ['அ', 'ஆ', 'இ', 'ஈ', 'உ', 'ஊ', 'எ', 'ஏ', 'ஐ', 'ஒ', 'ஓ', 'ஔ'],
    consonants: ['க', 'ங', 'ச', 'ஞ', 'ட', 'ண', 'த', 'ந', 'ப', 'ம', 'ய', 'ர', 'ல', 'வ', 'ழ', 'ள', 'ற', 'ன'],
    combinations: ['கா', 'கி', 'கீ', 'கு', 'கூ', 'கெ', 'கே', 'கை', 'கொ', 'கோ', 'கௌ', 'ங்', 'ச்', 'ட்', 'த்', 'ப்', 'ம்', 'ய்', 'ர்', 'ல்', 'வ்', 'ழ்', 'ள்', 'ற்', 'ன்']
};

// DOM Elements
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const keyboardToggle = document.getElementById('keyboardToggle');
const tamilKeyboard = document.getElementById('tamilKeyboard');
const closeKeyboard = document.getElementById('closeKeyboard');
const resultsDiv = document.getElementById('results');
const noResultsDiv = document.getElementById('noResults');
const loadingDiv = document.getElementById('loading');
const onlineSearchCheckbox = document.getElementById('onlineSearch');
const exampleBtns = document.querySelectorAll('.example-btn');

// Initialize Tamil Keyboard
function initKeyboard() {
    const vowelsRow = document.getElementById('vowels');
    const consonantsRow = document.getElementById('consonants');
    const combinationsRow = document.getElementById('combinations');
    
    tamilChars.vowels.forEach(char => {
        const btn = document.createElement('button');
        btn.className = 'key-btn';
        btn.textContent = char;
        btn.onclick = () => insertChar(char);
        vowelsRow.appendChild(btn);
    });
    
    tamilChars.consonants.forEach(char => {
        const btn = document.createElement('button');
        btn.className = 'key-btn';
        btn.textContent = char;
        btn.onclick = () => insertChar(char);
        consonantsRow.appendChild(btn);
    });
    
    tamilChars.combinations.forEach(char => {
        const btn = document.createElement('button');
        btn.className = 'key-btn';
        btn.textContent = char;
        btn.onclick = () => insertChar(char);
        combinationsRow.appendChild(btn);
    });
}

function insertChar(char) {
    const cursorPos = searchInput.selectionStart;
    const textBefore = searchInput.value.substring(0, cursorPos);
    const textAfter = searchInput.value.substring(cursorPos);
    searchInput.value = textBefore + char + textAfter;
    searchInput.focus();
    searchInput.setSelectionRange(cursorPos + char.length, cursorPos + char.length);
}

// Keyboard Controls
keyboardToggle.addEventListener('click', () => {
    tamilKeyboard.classList.toggle('hidden');
});

closeKeyboard.addEventListener('click', () => {
    tamilKeyboard.classList.add('hidden');
});

document.getElementById('backspaceBtn').addEventListener('click', () => {
    searchInput.value = searchInput.value.slice(0, -1);
    searchInput.focus();
});

document.getElementById('clearBtn').addEventListener('click', () => {
    searchInput.value = '';
    searchInput.focus();
});

document.getElementById('spaceBtn').addEventListener('click', () => {
    insertChar(' ');
});

// Event Listeners
searchBtn.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});

exampleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const word = btn.getAttribute('data-word');
        searchInput.value = word;
        performSearch();
    });
});

// Search Function
async function performSearch() {
    const searchTerm = searchInput.value.trim();
    
    if (!searchTerm) {
        alert('தயவுசெய்து ஒரு சொல்லை உள்ளிடவும்');
        return;
    }
    
    // Hide previous results
    resultsDiv.classList.add('hidden');
    noResultsDiv.classList.add('hidden');
    
    // Check local dictionary first
    const localResult = dictionary[searchTerm];
    
    if (localResult) {
        displayResult(searchTerm, localResult, 'Local Dictionary');
        return;
    }
    
    // If not found locally and online search is enabled
    if (onlineSearchCheckbox.checked) {
        await searchOnline(searchTerm);
    } else {
        displayNoResults();
    }
}

// Online Search Function (using multiple APIs)
async function searchOnline(word) {
    loadingDiv.classList.remove('hidden');
    
    try {
        // Try Wiktionary API
        const result = await searchWiktionary(word);
        if (result) {
            displayResult(word, result, 'Wiktionary');
            return;
        }
        
        // If Wiktionary fails, try Google Translate API (free tier)
        const translateResult = await searchGoogleTranslate(word);
        if (translateResult) {
            displayResult(word, translateResult, 'Google Translate');
            return;
        }
        
        displayNoResults();
    } catch (error) {
        console.error('Search error:', error);
        displayNoResults();
    } finally {
        loadingDiv.classList.add('hidden');
    }
}

// Wiktionary API Search
async function searchWiktionary(word) {
    try {
        const url = `https://en.wiktionary.org/api/rest_v1/page/definition/${encodeURIComponent(word)}`;
        const response = await fetch(url);
        
        if (!response.ok) return null;
        
        const data = await response.json();
        
        if (data.ta && data.ta.length > 0) {
            const definition = data.ta[0];
            return {
                type: 'பொதுவான சொல் (General Word)',
                tamilMeaning: definition.definitions[0]?.definition || 'பொருள் கிடைக்கவில்லை',
                englishMeaning: definition.definitions[0]?.definition || 'Meaning not available',
                examples: definition.definitions[0]?.examples || [],
                etymology: 'Wiktionary மூலம்'
            };
        }
        
        return null;
    } catch (error) {
        console.error('Wiktionary error:', error);
        return null;
    }
}

// Google Translate API (using free endpoint)
async function searchGoogleTranslate(word) {
    try {
        // Using MyMemory Translation API (free, no key required)
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=ta|en`;
        const response = await fetch(url);
        
        if (!response.ok) return null;
        
        const data = await response.json();
        
        if (data.responseData && data.responseData.translatedText) {
            return {
                type: 'மொழிபெயர்ப்பு (Translation)',
                tamilMeaning: word,
                englishMeaning: data.responseData.translatedText,
                examples: [],
                etymology: 'MyMemory Translation API மூலம்'
            };
        }
        
        return null;
    } catch (error) {
        console.error('Translation error:', error);
        return null;
    }
}

// Display Result
function displayResult(word, data, source) {
    noResultsDiv.classList.add('hidden');
    loadingDiv.classList.add('hidden');
    resultsDiv.classList.remove('hidden');
    
    // Update source badge
    document.getElementById('sourceBadge').textContent = `📚 Source: ${source}`;
    
    // Update word and type
    document.getElementById('searchedWord').textContent = word;
    document.getElementById('wordType').textContent = data.type;
    
    // Update meanings
    document.getElementById('tamilMeaning').textContent = data.tamilMeaning;
    document.getElementById('englishMeaning').textContent = data.englishMeaning;
    
    // Update examples
    const examplesList = document.getElementById('examplesList');
    if (data.examples && data.examples.length > 0) {
        document.getElementById('examplesSection').style.display = 'block';
        examplesList.innerHTML = data.examples.map(example => 
            `<div class="example-item">• ${example}</div>`
        ).join('');
    } else {
        document.getElementById('examplesSection').style.display = 'none';
    }
    
    // Update etymology
    if (data.etymology) {
        document.getElementById('etymologySection').style.display = 'block';
        document.getElementById('etymology').textContent = data.etymology;
    } else {
        document.getElementById('etymologySection').style.display = 'none';
    }
    
    // Scroll to results
    resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Display No Results
function displayNoResults() {
    resultsDiv.classList.add('hidden');
    loadingDiv.classList.add('hidden');
    noResultsDiv.classList.remove('hidden');
    noResultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Initialize
initKeyboard();
searchInput.focus();
