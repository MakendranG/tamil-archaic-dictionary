# Deployment Guide - Tamil Archaic Word Dictionary

This guide covers multiple deployment options for your Tamil Archaic Word Dictionary.

## Prerequisites

- Git installed on your system
- GitHub account
- Project files ready

## Option 1: GitHub Pages (Easiest & Free)

### Step 1: Create GitHub Repository

```bash
# Initialize git in your project folder
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Tamil Archaic Word Dictionary"
```

### Step 2: Push to GitHub

```bash
# Create a new repository on GitHub (via web interface)
# Then link it:
git remote add origin https://github.com/YOUR_USERNAME/tamil-archaic-dictionary.git
git branch -M main
git push -u origin main
```

### Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages**
3. Under "Source", select **main** branch
4. Click **Save**
5. Your site will be live at: `https://YOUR_USERNAME.github.io/tamil-archaic-dictionary`

**Time to Deploy**: 2-3 minutes after push

---

## Option 2: Netlify (Recommended for Custom Domain)

### Method A: Deploy via Git

1. Go to [netlify.com](https://netlify.com) and sign up
2. Click **"New site from Git"**
3. Connect your GitHub account
4. Select your repository
5. Click **Deploy site**

**Build Settings** (leave as default):
- Build command: (leave empty)
- Publish directory: (leave empty or use `/`)

### Method B: Drag & Drop

1. Go to [netlify.com/drop](https://netlify.com/drop)
2. Drag your project folder
3. Site goes live instantly!

**Custom Domain**: 
- Go to Site settings → Domain management
- Add your custom domain

**Time to Deploy**: 1-2 minutes

---

## Option 3: Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
cd tamil-archaic-dictionary
vercel

# Follow prompts:
# - Set up and deploy? Yes
# - Which scope? Your account
# - Link to existing project? No
# - Project name? tamil-archaic-dictionary
# - Directory? ./
# - Override settings? No
```

**Time to Deploy**: 1 minute

---

## Option 4: AWS S3 Static Website Hosting

### Step 1: Create S3 Bucket

```bash
# Install AWS CLI first
# Then create bucket
aws s3 mb s3://tamil-dictionary-YOUR_NAME --region us-east-1
```

### Step 2: Upload Files

```bash
# Upload all files
aws s3 sync . s3://tamil-dictionary-YOUR_NAME \
  --exclude ".git/*" \
  --exclude ".kiro/*" \
  --exclude "*.md"
```

### Step 3: Enable Static Website Hosting

```bash
# Enable website hosting
aws s3 website s3://tamil-dictionary-YOUR_NAME \
  --index-document index.html \
  --error-document index.html
```

### Step 4: Set Bucket Policy

Create a file `bucket-policy.json`:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadGetObject",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::tamil-dictionary-YOUR_NAME/*"
    }
  ]
}
```

Apply policy:

```bash
aws s3api put-bucket-policy \
  --bucket tamil-dictionary-YOUR_NAME \
  --policy file://bucket-policy.json
```

**Access URL**: `http://tamil-dictionary-YOUR_NAME.s3-website-us-east-1.amazonaws.com`

**Time to Deploy**: 5-10 minutes

---

## Option 5: Firebase Hosting

### Step 1: Install Firebase CLI

```bash
npm install -g firebase-tools
```

### Step 2: Initialize Firebase

```bash
# Login
firebase login

# Initialize
firebase init hosting

# Select:
# - Use existing project or create new
# - Public directory: . (current directory)
# - Single-page app: No
# - GitHub deploys: No
```

### Step 3: Deploy

```bash
firebase deploy
```

**Time to Deploy**: 2-3 minutes

---

## Testing Your Deployment

After deployment, test these features:

### ✅ Checklist

- [ ] Page loads correctly
- [ ] Tamil keyboard opens and works
- [ ] Search functionality works
- [ ] Example buttons work
- [ ] Online search works (if enabled)
- [ ] Mobile responsive design works
- [ ] All Tamil characters display correctly

### Test URLs

```bash
# Local testing
python -m http.server 8000
# Visit: http://localhost:8000

# Or use Node.js
npx http-server
```

---

## Custom Domain Setup

### For GitHub Pages

1. Buy domain from Namecheap, GoDaddy, etc.
2. Add CNAME file to repository:
   ```
   yourdomain.com
   ```
3. Configure DNS:
   - Type: CNAME
   - Name: www
   - Value: YOUR_USERNAME.github.io

### For Netlify

1. Go to Site settings → Domain management
2. Click "Add custom domain"
3. Follow DNS configuration instructions

### For AWS S3

1. Use CloudFront for HTTPS
2. Configure Route 53 for DNS
3. Add SSL certificate via ACM

---

## Continuous Deployment

### GitHub Actions (for GitHub Pages)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./
```

---

## Monitoring & Analytics

### Add Google Analytics

Add before `</head>` in index.html:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

---

## Troubleshooting

### Issue: Tamil characters not displaying

**Solution**: Ensure UTF-8 encoding in HTML:
```html
<meta charset="UTF-8">
```

### Issue: API calls blocked (CORS)

**Solution**: APIs used (Wiktionary, MyMemory) support CORS. If issues persist, check browser console.

### Issue: Site not updating after push

**Solution**: 
- Clear browser cache (Ctrl+Shift+R)
- Wait 2-3 minutes for CDN propagation
- Check deployment logs

---

## Performance Optimization

### Enable Caching

For Netlify, create `netlify.toml`:

```toml
[[headers]]
  for = "/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000"
```

### Compress Assets

```bash
# Install gzip
# Compress CSS and JS
gzip -k style.css
gzip -k script.js
```

---

## Security Best Practices

1. **HTTPS**: Always use HTTPS (automatic on GitHub Pages, Netlify, Vercel)
2. **CSP Headers**: Add Content Security Policy
3. **No Sensitive Data**: Don't commit API keys (we're using free APIs, so no keys needed)

---

## Cost Comparison

| Platform | Cost | Custom Domain | SSL | CDN |
|----------|------|---------------|-----|-----|
| GitHub Pages | Free | Yes | Yes | Yes |
| Netlify | Free | Yes | Yes | Yes |
| Vercel | Free | Yes | Yes | Yes |
| AWS S3 | ~$0.50/mo | Extra | Extra | Extra |
| Firebase | Free | Yes | Yes | Yes |

**Recommendation**: Start with GitHub Pages or Netlify (both free and feature-rich)

---

## Support

If you encounter issues:

1. Check deployment logs
2. Test locally first
3. Review browser console for errors
4. Check API status (Wiktionary, MyMemory)

---

**Ready to deploy? Choose your platform and follow the steps above!**

Good luck with your AI for Bharat submission! 🚀
